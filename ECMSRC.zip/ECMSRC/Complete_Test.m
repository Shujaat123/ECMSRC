%%%%%%%%%%%%%This code evaluates the ECM prediction data using SRC with
clc
close all
clear all
addpath L1_tools

load feature_with_mRMr_d
load train_new.csv;
load test_new.csv;

class_train=train_new(:,1);
class_test=test_new(:,1);

classes=2;
train=300;
n=classes*train;
train_1=train_new(:,2:end)';
test_1=test_new(:,2:end)';

for ind=29
feature_length=ind;
A=train_1(feature_with_mRMr_d(1:feature_length),:)+0.0001; %Dictionary matrix%

ROC_MAT=[];

count=0;

for i=1:size(test_1,2);
    y=test_1(feature_with_mRMr_d(1:feature_length),i)+0.0001;

x0=A\y;

% x0=pinv(A)*y;
%%%

% Backslash or matrix left division. If A is a square matrix, A\B is roughly
% the same as inv(A)*B, except it is computed in a different way. If A is an
% n-by-n matrix and B is a column vector with n components, or a matrix with 
% several such columns, then X = A\B is the solution to the equation AX = B.
% A warning message is displayed if A is badly scaled or nearly singular. 
% See the reference page for mldivide for more information.

% If A is an m-by-n matrix with m ~= n and B is a column vector with m 
% components, or a matrix with several such columns, then X = A\B is the 
% solution in the least squares sense to the under- or overdetermined system
% of equations AX = B. The effective rank, k, of A is determined from the 
% QR decomposition with pivoting. A solution X is computed that has at most
% k nonzero components per column. If k < n, this is usually not the same 
% solution as pinv(A)*B, which is the least squares solution with the 
% smallest norm .

%%%

xp=l1qc_logbarrier(x0,A,[],y,0.05, 0.01);

delta=zeros(n,1);
score=zeros(classes,1);
k=1;

for u=1:train:train*classes
    delta(u:u+train-1,1)=xp(u:u+train-1,1);
    
    yp=A*delta;
    r_y=sum((y-yp).^2).^0.5;
    score(k,1)=r_y;
    delta=zeros(n,1);
    k=k+1;     
end

%%%Decision rule
ROC_MAT=[ROC_MAT score];
[value,class]=min(score);
if class==class_test(i)
    count=count+1;
end
[1000*count/i count i]
     end
(count/i)*100

% save(strcat('ROC_Independent',num2str(ind),'.mat'),'ROC_MAT','class_test','feature_length');
end