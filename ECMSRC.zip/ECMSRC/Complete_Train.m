%%%%%%%%%%%%%This code evaluates the ECM prediction data using SRC with
clc
close all
clear all
addpath L1_tools

load feature_with_mRMr_d
load train_new.csv;
load test_new.csv;

class_train=train_new(:,1);
class_test=test_new(:,1);

classes=2;
train=300;
n=classes*train;
train_1=train_new(:,2:end)';

for ind=29
feature_length=ind;
A=train_1(feature_with_mRMr_d(1:feature_length),:)+0.0001; %Dictionary matrix%

ROC_MAT=[];

count=0;

for i=[1:size(train_1,2)];
    y=train_1(feature_with_mRMr_d(1:feature_length),i)+0.0001;
    
x0=A\y;
xp=l1qc_logbarrier(x0,A,[],y,0.05, 0.01);

delta=zeros(n,1);
score=zeros(classes,1);
k=1;

for u=1:train:train*classes

    delta(u:u+train-1,1)=xp(u:u+train-1,1);
      
    yp=A*delta;
    r_y=sum((y-yp).^2).^0.5;
    score(k,1)=r_y;
    delta=zeros(n,1);
    k=k+1;     
end

%%%Decision rule
ROC_MAT=[ROC_MAT score];
[value,class]=min(score);
if class==class_train(i)
    count=count+1;
end
[count/i count i]
     end
(count/i)*100

% save(strcat('ROC',num2str(ind),'.mat'),'ROC_MAT','class_train','feature_length');
end